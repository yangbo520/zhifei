根据各位建议加上了这部分内容，我暂时只是给出了两个资源，后续可能会对重要的点进行总结，然后更新在这里，如果你总结过这类东西，欢迎与我联系！

### 团队

- **阿里巴巴Java开发手册（详尽版）** <https://github.com/alibaba/p3c/blob/master/阿里巴巴Java开发手册（华山版）.pdf>
- **Google Java编程风格指南：** <http://hawstein.com/2014/01/20/google-java-style/>

### 个人

- **程序员你为什么这么累:** <https://xwjie.github.io/rule/>
